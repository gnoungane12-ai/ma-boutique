// script.js - panier complet (FR) avec persistence localStorage
(function(){
  const products = [
    { id:1, name:"T‑shirt coloré", price:19.99, stock:12, img:"https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=1c2d1a2b8a9f4a8b5e2b8a6b5d4f1e2a" },
    { id:2, name:"Pull moderne", price:49.99, stock:7, img:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=3c4f5b6a7b8c9d0e1f2a3b4c5d6e7f8a" },
    { id:3, name:"iPhone élégant", price:799.00, stock:4, img:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=9d8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a" },
    { id:4, name:"Samsung Galaxy", price:699.00, stock:6, img:"https://images.unsplash.com/photo-1510557880182-3f8e8f9c9f5b?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c3d" },
    { id:5, name:"Baskets blanches", price:59.99, stock:10, img:"https://images.unsplash.com/photo-1520975681373-9f1f6a8a3a2b?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=7b6a5c4d3e2f1a0b9c8d7e6f5a4b3c2d" },
    { id:6, name:"Chaussures sportives", price:74.99, stock:8, img:"https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d" }
  ];

  // read/write localStorage
  function read(k, fallback){ try{ const r = localStorage.getItem(k); return r?JSON.parse(r):fallback; }catch(e){return fallback;} }
  function write(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }

  let cart = read('mbc_cart', []);

  // DOM
  const productsEl = document.getElementById('products');
  const cartCount = document.getElementById('cartCount');
  const cartItems = document.getElementById('cartItems');
  const empty = document.getElementById('empty');
  const totalEl = document.getElementById('total');
  const checkout = document.getElementById('checkout');
  const clearBtn = document.getElementById('clear');

  function renderProducts(){
    productsEl.innerHTML = '';
    const stored = read('mbc_products', products);
    stored.forEach(p=>{
      const div = document.createElement('div');
      div.className = 'card product';
      div.innerHTML = `
        <div class="thumb" style="background-image:url('${p.img}')"></div>
        <div class="pname">${p.name}</div>
        <div class="pprice">€${p.price.toFixed(2)}</div>
        <div class="pstock ${p.stock===0?'muted':''}">Stock: ${p.stock}</div>
        <div class="row">
          <button class="btn add" data-id="${p.id}" ${p.stock===0?'disabled':''}>Ajouter au panier</button>
          <button class="btn" data-dec="${p.id}">-</button>
          <button class="btn" data-inc="${p.id}">+</button>
        </div>
      `;
      productsEl.appendChild(div);
    });
    # events
  }
    document.querySelectorAll('.add').forEach(b=>b.onclick=()=>addToCart(Number(b.dataset.id)));
    document.querySelectorAll('[data-dec]').forEach(b=>b.onclick=()=>adjustStock(Number(b.dataset.dec), -1));
    document.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>adjustStock(Number(b.dataset.inc), +1));
  }

  function renderCart(){
    cartItems.innerHTML = '';
    if(cart.length===0){ empty.style.display='block'; checkout.disabled=true; } else { empty.style.display='none'; checkout.disabled=false; }
    cart.forEach(item=>{
      const li = document.createElement('li');
      li.innerHTML = `
        <div>
          <div style="font-weight:600">${item.name}</div>
          <div class="muted">${item.qty} × €${item.price.toFixed(2)}</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <input class="input-small" data-q="${item.id}" type="number" min="1" value="${item.qty}">
          <button class="btn" data-rm="${item.id}">Suppr</button>
        </div>
      `;
      cartItems.appendChild(li);
    });
    document.querySelectorAll('[data-q]').forEach(inp=>inp.onchange=(e)=>changeQty(Number(inp.dataset.q), Number(inp.value)));
    document.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>removeFromCart(Number(b.dataset.rm)));
    cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0);
    totalEl.textContent = cart.reduce((s,i)=>s + i.qty*i.price,0).toFixed(2);
  }

  function addToCart(id){
    const stored = read('mbc_products', products);
    const p = stored.find(x=>x.id===id);
    if(!p || p.stock<=0){ alert('Produit en rupture de stock'); return; }
    const exists = cart.find(i=>i.id===id);
    if(exists){ if(exists.qty+1>p.stock){ alert('Stock insuffisant'); return;} exists.qty+=1; } else { cart.push({ id:id, qty:1, name:p.name, price:p.price }); }
    write('mbc_cart', cart);
    renderCart();
  }

  function removeFromCart(id){ cart = cart.filter(i=>i.id!==id); write('mbc_cart', cart); renderCart(); }

  function changeQty(id, qty){ qty = Math.max(1, Number(qty)||1); const stored = read('mbc_products', products); const p = stored.find(x=>x.id===id); if(qty>p.stock){ alert('Quantité supérieure au stock'); return; } cart = cart.map(i=>i.id===id?{...i, qty}:i); write('mbc_cart', cart); renderCart(); }

  function adjustStock(id, delta){ const stored = read('mbc_products', products); const next = stored.map(p=>p.id===id?{...p, stock: Math.max(0, p.stock+delta)}:p); write('mbc_products', next); renderProducts(); }

  function checkoutOrder(){
    // verify stock
    const stored = read('mbc_products', products);
    for(const it of cart){
      const p = stored.find(x=>x.id===it.id);
      if(!p || p.stock < it.qty){ alert(`Stock insuffisant pour ${it.name}`); return; }
    }
    // decrement
    const updated = stored.map(p=>{ const c = cart.find(i=>i.id===p.id); return c?{...p, stock: p.stock - c.qty}:p; });
    write('mbc_products', updated);
    cart=[]; write('mbc_cart', cart);
    renderAll();
    alert('Commande passée — merci !');
  }

  function clearCart(){ if(!confirm('Vider le panier ?')) return; cart=[]; write('mbc_cart', cart); renderCart(); }

  // events
  checkout.onclick = checkoutOrder;
  clearBtn.onclick = clearCart;

  function renderAll(){ renderProducts(); renderCart(); }

  // init
  renderAll();
  // sidebar toggle for small screens
  const cartToggle = document.getElementById('cartToggle');
  const sidebar = document.getElementById('sidebar');
  cartToggle.onclick = ()=>{ sidebar.scrollIntoView({behavior:'smooth'}); };
})();
