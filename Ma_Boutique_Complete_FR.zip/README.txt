Ma Boutique Colorée — Version complète (FR)
===========================================

Ce dossier contient un site statique prêt pour GitHub Pages.

Fichiers inclus :
- index.html
- style.css
- script.js
- README.txt

Comment publier sur GitHub Pages :
1) Va sur ton dépôt 'ma-boutique' (compte: gnoungane12-ai)
2) Téléverse ces fichiers dans le dépôt (Ajouter un fichier → Téléverser des fichiers).
3) Dans Paramètres → Pages, choisissez :
   - Branche : main
   - Dossier : / (root)
   - Enregistrer
4) Attendre ~1 minute puis visiter :
   https://gnoungane12-ai.github.io/ma-boutique/

Personnalisation :
- Pour changer les images, modifiez les URL dans script.js (champ img pour chaque produit).
- Pour changer les prix, modifiez les valeurs price dans script.js.
- Tout est en français et utilise localStorage pour le panier et le stock.

Bon succès — dis-moi si tu veux que je te fasse les captures d'écran pour téléverser.
